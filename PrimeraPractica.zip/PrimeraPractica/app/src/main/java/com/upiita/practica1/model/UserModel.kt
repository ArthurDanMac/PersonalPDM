package com.upiita.practica1.model

data class UserModel (
    var name:String,
    var email:String,
    var passwd:String,
    var pregunta:String,
    var respuesta:String
)